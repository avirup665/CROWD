namespace BTCPayServer.Abstractions.Constants;

public class WellKnownTempData
{
    public const string SuccessMessage = nameof(SuccessMessage);
    public const string ErrorMessage = nameof(ErrorMessage);
}
