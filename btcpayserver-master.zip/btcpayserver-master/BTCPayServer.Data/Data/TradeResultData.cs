namespace BTCPayServer.Data;

public class TradeResultData
{

}
