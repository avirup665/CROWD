This tool makes it easy to create a BTCPay plugin package. To create a package you must:
* Build your BTCPay Plugin project
* open a terminal in this project
* run `dotnet run PATH_TO_PLUGIN_BUILD_DIRECTORY NAME_OF_PLUGIN BUILT_PACKAGE_OUTPUT_DIRECTORY`
