namespace BTCPayServer.Client.Models
{
    public class LightningNetworkPaymentMethodBaseData
    {

        public string ConnectionString { get; set; }
        public LightningNetworkPaymentMethodBaseData()
        {

        }
    }
}
