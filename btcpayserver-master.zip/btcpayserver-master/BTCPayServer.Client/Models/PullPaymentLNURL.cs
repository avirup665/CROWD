namespace BTCPayServer.Client.Models
{
    public class PullPaymentLNURL
    {
        public string LNURLBech32 { get; set; }
        public string LNURLUri { get; set; }
    }
}
