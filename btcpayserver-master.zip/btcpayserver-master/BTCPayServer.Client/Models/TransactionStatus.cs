namespace BTCPayServer.Client.Models
{
    public enum TransactionStatus
    {
        Unconfirmed,
        Confirmed
    }
}
