namespace BTCPayServer.Client;

public class ApproveUserRequest
{
    public bool Approved { get; set; }
}
