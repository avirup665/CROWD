namespace BTCPayServer.Client;

public class LockUserRequest
{
    public bool Locked { get; set; }
}
