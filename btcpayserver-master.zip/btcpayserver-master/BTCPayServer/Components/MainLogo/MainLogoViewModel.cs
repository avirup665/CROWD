namespace BTCPayServer.Components.MainLogo
{
    public class MainLogoViewModel
    {
        public string CssClass { get; set; }
    }
}
