using System.Collections.Generic;

namespace BTCPayServer.Components.Icon
{
    public class IconViewModel
    {
        public string Symbol { get; set; }
    }
}
